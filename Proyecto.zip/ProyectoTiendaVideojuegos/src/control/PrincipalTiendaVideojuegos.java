package control;

import java.util.Scanner;

import vista.Entradas;
import vista.Salidas;

public class PrincipalTiendaVideojuegos {
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		String perfil;
		System.out.println("***************************************************");
		System.out.println("\t \tBIENVENIDO");
		System.out.println("***************************************************");
		System.out.println("¿DESEAS INICIAR COMO CLIENTE O COMO ADMINISTRADOR? ");
		perfil = scan.next();
		if (perfil.equals("c")) {
			int opcion = 0;
			Salidas.mostrarMenuCliente();
			opcion = Entradas.leerOpcion();
			AccionesController ac = new AccionesController(opcion);
			while (opcion != 0) {
				ac.accionOpcionCliente();
				Salidas.mostrarMenuCliente();
				opcion = Entradas.leerOpcion();
				ac.setOpcion(opcion);

			}
			System.out.println("CIERRE APLICACIÓN");
			}else if(perfil.equals("a")){
				int opcion = 0;
				Salidas.mostrarMenuAdmin();
				opcion = Entradas.leerOpcion();
				AccionesController ac = new AccionesController(opcion);
				while (opcion != 0) {
					ac.accionOpcionAdmin();
					Salidas.mostrarMenuAdmin();
					opcion = Entradas.leerOpcion();
					ac.setOpcion(opcion);
			}
			System.out.println("CIERRE APLICACIÓN");
			// HACER QUE AL ESCOGER LA OPCION 3 DEL MENU NOS SALGAN LOS VIDEOJUEGOS
			// RELACIONADOS CON EL GENERO SELECCIONADO

		}

	}
}
