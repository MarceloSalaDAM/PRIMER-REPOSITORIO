package control;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import modelo.Plataformas;
import modelo.Tematicas;
import modelo.Videojuegos;
import modelo.dao.PlataformasDAO;
import modelo.dao.TematicasDAO;
import modelo.dao.VideojuegosDAO;
import vista.Entradas;
import vista.Salidas;

public class AccionesController {
	private int opcion;

	public AccionesController(int opcion) {
		super();
		this.opcion = opcion;
	}

	public AccionesController() {
		super();

	}

	public int getOpcion() {
		return opcion;
	}

	public void setOpcion(int opcion) {
		this.opcion = opcion;
	}
	
	

	public void accionOpcionCliente() {
		switch (opcion) {

		case 1:
			List<Tematicas> listaTem = new ArrayList<Tematicas>();
			listaTem = TematicasDAO.seleccionarTematicas();
			Salidas.mostrarListaTematicas(listaTem);
			break;
		case 2:
			List<Videojuegos> listaVid = new ArrayList<Videojuegos>();
			listaVid = VideojuegosDAO.seleccionarVideojuegos();
			Salidas.mostrarListaVideojuegos(listaVid);
			break;

		case 3:
			/*
			 * Salidas.mostrarListaTematicas(TematicasDAO.buscarTematica(Entradas.
			 * mostrarTematica())); break;
			 */
			listaVid = VideojuegosDAO.seleccionarVideojuegos();
			listaVid.sort(null);
			Map<Integer, String> mapaVT = new HashMap<Integer, String>();

			int cont = 0;
			for (Videojuegos v : listaVid) {
				if (mapaVT.get(v.getTematica().getIdTematica()) == null) {
					mapaVT.put(1, v.getTematica().getGenero());
				} else {
					mapaVT.put(v.getTematica().getIdTematica(), mapaVT.get(v.getTematica().getGenero()) + 1);
				}
			}
			Iterator<Integer> it = mapaVT.keySet().iterator();
			int s;
			while (it.hasNext()) {
				s = it.next();
				System.out.println(s + "- " + mapaVT.get(s));
			}
			Salidas.mostrarListaVideojuegos(listaVid);
			break;
		case 4:
			List<Plataformas> listaPlat = new ArrayList<Plataformas>();
			listaPlat = PlataformasDAO.seleccionarPlataforma();
			Salidas.mostrarListaPlataformas(listaPlat);
			break;

		}

	}

	public void accionOpcionAdmin() {
		switch (opcion) {

		case 1:
			TematicasDAO.insertarTematica(Entradas.crearTematica());
			break;
		case 2:
			VideojuegosDAO.insertarVideojuego(Entradas.insertarVideojuego());
			break;

		}
	}
}