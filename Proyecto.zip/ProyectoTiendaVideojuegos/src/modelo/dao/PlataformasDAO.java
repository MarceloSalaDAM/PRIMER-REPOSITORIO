package modelo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Plataformas;


public class PlataformasDAO {
	public static List<Plataformas> seleccionarPlataforma() {
		List<Plataformas> listaPlataformas = new ArrayList<Plataformas>();
		ResultSet rs = null;

		try {
			EnlaceJDBC enlaceBD = new EnlaceJDBC();
			String sqlQuery = "select * from PLATAFORMAS";
			rs = enlaceBD.seleccionRegistros(sqlQuery);
			while (rs.next()) {
				listaPlataformas.add(new Plataformas(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4)));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return listaPlataformas;

	}
}
