package modelo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Tematicas;
import modelo.Videojuegos;

public class VideojuegosDAO {
	public static List<Videojuegos> seleccionarVideojuegos() {
		List<Videojuegos> listaVideojuegos = new ArrayList<Videojuegos>();
		ResultSet rs = null;

		try {
			EnlaceJDBC enlaceBD = new EnlaceJDBC();
			String sqlQuery = "select * from VIDEOJUEGOS order by tematica_id";
			rs = enlaceBD.seleccionRegistros(sqlQuery);
			while (rs.next()) {
				listaVideojuegos.add(new Videojuegos(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4),
						rs.getString(5), rs.getDate(6).toLocalDate(), new Tematicas(rs.getInt(7))));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return listaVideojuegos;

	}

	public static void insertarVideojuego(Videojuegos v) {
		int codigoT=0;
		try {
			EnlaceJDBC enlace = new EnlaceJDBC();
			codigoT=TematicasDAO.obtenerIdTematicas(v.getTematica().getGenero());
			String sql = "insert into VIDEOJUEGOS values (" + v.getCodVideojuego() + ",'" + v.getNombreVideojuego()
					+ "'," + v.getPegi() + "," + v.getPrecio() + ",'" + v.getDistribuidora() + "','"
					+ v.getFechaLanzamiento() + "'," + codigoT + ")";
			System.out.println(sql);
			
			  if (enlace.insertar(sql)) {
			  System.out.println("Se han insertado correctamente los datos"); }
			 
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}



}
