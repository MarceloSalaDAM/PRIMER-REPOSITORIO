package modelo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Tematicas;

public class TematicasDAO {
	public static List<Tematicas> seleccionarTematicas() {
		List<Tematicas> listaTematicas = new ArrayList<Tematicas>();
		ResultSet rs = null;

		try {
			EnlaceJDBC enlaceBD = new EnlaceJDBC();
			String sqlQuery = "select * from TEMATICAS";
			rs = enlaceBD.seleccionRegistros(sqlQuery);
			while (rs.next()) {
				listaTematicas.add(new Tematicas(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return listaTematicas;

	}

	public static void insertarTematica(Tematicas t) {
		try {
			EnlaceJDBC enlaceBD = new EnlaceJDBC();
			String sql = "insert into TEMATICAS(id_tematica,nombre_tematica,descripcion) values (" + t.getIdTematica()
					+ ",'" + t.getGenero() + "','" + t.getDescripcion() + "')";
			if (enlaceBD.insertar(sql))
				System.out.println("Has insertado correctamente los datos:");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static List<Tematicas> buscarTematica(String tematica) {

		List<Tematicas> listaTematicas = new ArrayList<Tematicas>();
		ResultSet rs = null;

		try {
			EnlaceJDBC enlaceBD = new EnlaceJDBC();
			String sqlQuery = "select nombre_tematica from TEMATICAS where nombre_tematica='" + tematica + "'";
			rs = enlaceBD.seleccionRegistros(sqlQuery);
			while (rs.next()) {
				listaTematicas.add(new Tematicas(0,rs.getString(1),rs.getString(2)));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return listaTematicas;

	}

	 public static int obtenerIdTematicas(String genero) {
		 int codigo=0;
		 ResultSet rs= null;
		 try {
		 EnlaceJDBC enlace = new EnlaceJDBC();
		 String querySql= "select id_tematica from TEMATICAS where nombre_tematica = '"+ genero+"'";
		 rs= enlace.seleccionRegistros(querySql);
		 if (rs.next()) {
		 codigo= rs.getInt(1);
		 }

		 } catch (SQLException e) {
		 // TODO Auto-generated catch block
		 e.printStackTrace();
		 }

		 return codigo;
		 }
}
