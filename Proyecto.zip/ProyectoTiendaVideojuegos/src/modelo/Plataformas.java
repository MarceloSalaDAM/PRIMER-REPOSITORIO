package modelo;

public class Plataformas {
	private int codPlataforma;
	private String tipo;
	private String nombre;
	private double precio;
	public Plataformas() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Plataformas(int codPlataforma, String tipo, String nombre, double precio) {
		super();
		this.codPlataforma = codPlataforma;
		this.tipo = tipo;
		this.nombre = nombre;
		this.precio = precio;
	}
	public int getCodPlataforma() {
		return codPlataforma;
	}
	public void setCodPlataforma(int codPlataforma) {
		this.codPlataforma = codPlataforma;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("codPlataforma:");
		builder.append(codPlataforma);
		builder.append("\nTipo=");
		builder.append(tipo);
		builder.append("\nNombre=");
		builder.append(nombre);
		builder.append("\nPrecio=");
		builder.append(precio);
		builder.append("");
		return builder.toString();
	}
	
	

}
