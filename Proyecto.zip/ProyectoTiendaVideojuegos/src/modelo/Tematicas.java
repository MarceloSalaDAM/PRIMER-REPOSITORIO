package modelo;

public class Tematicas {
	private int idTematica;
	private String genero;
	private String descripcion;

	public Tematicas() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Tematicas(int idTematica, String genero, String descripcion) {
		super();
		this.idTematica = idTematica;
		this.genero = genero;
		this.descripcion = descripcion;
	}

	public Tematicas(int idTematica) {
		super();
		this.idTematica = idTematica;
	}
	

	public Tematicas(int idTematica, String genero) {
		super();
		this.idTematica = idTematica;
		this.genero = genero;
	}

	public int getIdTematica() {
		return idTematica;
	}

	public void setIdTematica(int idTematica) {
		this.idTematica = idTematica;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("idTematica:");
		builder.append(idTematica);
		/*
		 * builder.append("\nGénero:"); builder.append(genero);
		 * builder.append("\nDescripcion:"); builder.append(descripcion);
		 * builder.append("\n");
		 */
		return builder.toString();
	}

}