package modelo;

import java.time.LocalDate;

public class Videojuegos {
	private int codVideojuego;
	private String nombreVideojuego;
	private int pegi;
	private int precio;
	private String distribuidora;
	private LocalDate fechaLanzamiento;
	private Tematicas tematica;

	public Videojuegos() {
		super();
		
	}
	

	public Videojuegos(int codVideojuego, String nombreVideojuego, int pegi, int precio, String distribuidora,
			LocalDate fechaLanzamiento, Tematicas tematica) {
		super();
		this.codVideojuego = codVideojuego;
		this.nombreVideojuego = nombreVideojuego;
		this.pegi = pegi;
		this.precio = precio;
		this.distribuidora = distribuidora;
		this.fechaLanzamiento = fechaLanzamiento;
		this.tematica = tematica;
	}
	

	public Videojuegos(Tematicas tematica) {
		super();
		this.tematica = tematica;
	}


	public int getCodVideojuego() {
		return codVideojuego;
	}

	public void setCodVideojuego(int codVideojuego) {
		this.codVideojuego = codVideojuego;
	}

	public String getNombreVideojuego() {
		return nombreVideojuego;
	}

	public void setNombreVideojuego(String nombreVideojuego) {
		this.nombreVideojuego = nombreVideojuego;
	}

	public int getPegi() {
		return pegi;
	}

	public void setPegi(int pegi) {
		this.pegi = pegi;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getDistribuidora() {
		return distribuidora;
	}

	public void setDistribuidora(String distribuidora) {
		this.distribuidora = distribuidora;
	}

	public LocalDate getFechaLanzamiento() {
		return fechaLanzamiento;
	}

	public void setFechaLanzamiento(LocalDate fechaLanzamiento) {
		this.fechaLanzamiento = fechaLanzamiento;
	}

	public Tematicas getTematica() {
		return tematica;
	}

	public void setTematica(Tematicas tematica) {
		this.tematica = tematica;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("\ncodVideojuego:");
		builder.append(codVideojuego);
		builder.append("\nNombreVideojuego:");
		builder.append(nombreVideojuego);
		builder.append("\nPegi:");
		builder.append(pegi);
		builder.append("\nPrecio:");
		builder.append(precio);
		builder.append("\nDistribuidora:");
		builder.append(distribuidora);
		builder.append("\nFecha Lanzamiento:");
		builder.append(fechaLanzamiento);
		builder.append("\nTematica:");
		builder.append(tematica);
		builder.append("\n");
		return builder.toString();
	}

}
