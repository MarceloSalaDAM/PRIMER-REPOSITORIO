package vista;

import java.util.ArrayList;
import java.util.List;

import modelo.Plataformas;
import modelo.Tematicas;
import modelo.Videojuegos;

public class Salidas {
	/*
	 * public static void mostrarMenu() { StringBuilder sb = new StringBuilder();
	 * sb.append("***************************************************");
	 * sb.append("\t \tBIENVENIDO");
	 * sb.append("***************************************************");
	 * sb.append("¿DESEAS INICIAR COMO CLIENTE O COMO ADMINISTRADOR? ");
	 * 
	 * }
	 */
	public static void mostrarMenuCliente() {
		StringBuilder sb = new StringBuilder();
		sb.append("------------------------------------------------------------------");
		sb.append("\n\t\tMENÚ DE OPCIONES TIENDA DE VIDEOJUEGOS");
		sb.append("\n------------------------------------------------------------------");
		sb.append("\n1.MOSTRAR GÉNEROS");
		sb.append("\n2.MOSTRAR VIDEOJUEGOS");
		sb.append("\n3.BUSCAR GENERO Y MOSTRAR VIDEOJUEGOS RELACIONADOS");
		sb.append("\n4.MOSTRAR PLATAFORMAS");
		sb.append("\n5.SELECCIONAR VIDEOJUEGO");
		sb.append("\n0.SALIR");
		sb.append("\n------------------------------------------------------------------");
		sb.append("\n\t\tELIJA UNA DE LAS OPCIONES");
		sb.append("\n------------------------------------------------------------------");
		System.out.println(sb.toString());

	}

	public static void mostrarMenuAdmin() {
		StringBuilder sb = new StringBuilder();
		sb.append("------------------------------------------------------------------");
		sb.append("\n\t\tMENÚ DE OPCIONES TIENDA DE VIDEOJUEGOS");
		sb.append("\n------------------------------------------------------------------");
		sb.append("\n1.INSERTAR GÉNEROS");
		sb.append("\n2.INSERTAR VIDEOJUEGOS");
		sb.append("\n0.SALIR");
		sb.append("\n------------------------------------------------------------------");
		sb.append("\n\t\tELIJA UNA DE LAS OPCIONES");
		sb.append("\n------------------------------------------------------------------");
		System.out.println(sb.toString());

	}

	public static void mostrarListaTematicas(List<Tematicas> seleccionarTematica) {
		/* List<Tematicas> lista = new ArrayList<Tematicas>(); */
		/* lista.addAll(seleccionarTematica); */
//		for (Tematicas t : lista) {
//			System.out.println(t);
//		}
		seleccionarTematica.forEach(
				(t) -> System.out.println("*" + t.getIdTematica() + "-" + t.getGenero() + ":" + t.getDescripcion()));

	}

	public static void mostrarListaVideojuegos(List<Videojuegos> seleccionarVideojuegos) {
		/* List<Videojuegos> listaV = new ArrayList<Videojuegos>(); */
		/*
		 * listaV.addAll(seleccionarVideojuegos); for (Videojuegos v : listaV) {
		 * System.out.println(v);
		 */

		seleccionarVideojuegos.forEach((v) -> System.out.println("\nCodVideojuego: " + v.getCodVideojuego()
				+ "\nNombre: " + v.getNombreVideojuego() + "\nClasificación: " + v.getPegi() + "\nPrecio: "
				+ v.getPrecio() + "€" + "\nDistribuidora: " + v.getDistribuidora() + "\nFecha Lanzamiento: "
				+ v.getFechaLanzamiento() + "\n" + v.getTematica()));
	}

	public static void mostrarListaPlataformas(List<Plataformas> seleccionarPlataforma) {
		/* List<Tematicas> lista = new ArrayList<Tematicas>(); */
		/* lista.addAll(seleccionarTematica); */
//		for (Tematicas t : lista) {
//			System.out.println(t);
//		}
		seleccionarPlataforma.forEach(
				(p) -> System.out.println("*" + p.getCodPlataforma() + "-" + p.getTipo() + ":" + p.getNombre()+"-"+p.getPrecio()));

	}
}
