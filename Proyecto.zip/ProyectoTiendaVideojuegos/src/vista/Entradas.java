package vista;

import java.time.LocalDate;
import java.util.Scanner;

import modelo.Tematicas;
import modelo.Videojuegos;

public class Entradas {
	private static Scanner scan = new Scanner(System.in);

	public static int leerOpcion() {

		return scan.nextInt();
	}

	public static String mostrarTematica() {
		System.out.println("Que genero estas buscando:");

		return scan.next();

	}

	public static Tematicas crearTematica() {
		System.out.println("Inserte el id : ");
		Tematicas t = new Tematicas();
		t.setIdTematica(scan.nextInt());
		System.out.println("Nombre");
		t.setGenero(scan.next());
		System.out.println("Descripción:");
		t.setDescripcion(scan.next());
		return t;
	}

	public static Videojuegos insertarVideojuego() {

		Videojuegos v = new Videojuegos();
		v.setCodVideojuego(0);
		System.out.println("Nombre:");
		v.setNombreVideojuego(scan.next());
		System.out.println("Clasificación:");
		v.setPegi(scan.nextInt());
		System.out.println("Plataforma:");
		v.setPrecio(scan.nextInt());
		System.out.println("Distribuidora:");
		v.setDistribuidora(scan.next());
		System.out.println("Fecha Lanzamiento (YYYY-MM-DD):");
		v.setFechaLanzamiento(LocalDate.parse(scan.next()));
		System.out.println("Género: ");
		v.setTematica(new Tematicas(0,scan.next()));

		return v;
	}

}
